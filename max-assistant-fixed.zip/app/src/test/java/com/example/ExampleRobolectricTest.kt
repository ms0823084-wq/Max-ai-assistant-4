package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Max Assistant", appName)
  }

  @Test
  fun `verify license generation and offline validation`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val securityManager = com.example.data.local.SecurityManager(context)
    val key = securityManager.generateLicenseKey(securityManager.deviceId, com.example.data.model.LicensePlan.LIFETIME)
    val status = securityManager.validateLicense(key)
    org.junit.Assert.assertTrue(status.isValid)
    assertEquals(com.example.data.model.LicensePlan.LIFETIME, status.plan)
  }
}
