package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.screens.AntiTheftScreen
import com.example.ui.screens.IntruderLogScreen
import com.example.ui.screens.LicenseScreen
import com.example.ui.screens.MainAssistantScreen
import com.example.ui.screens.PermissionsScreen
import com.example.ui.screens.PrivacyScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.VisionScreen
import com.example.ui.screens.WhatsAppBotScreen
import com.example.ui.theme.CyberNavy
import com.example.ui.theme.DarkSapphire
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.MaxAssistantTheme
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class Screen {
    ASSISTANT,
    VISION,
    ANTI_THEFT,
    WHATSAPP,
    SETTINGS,
    INTRUDER_LOGS,
    LICENSE,
    PERMISSIONS,
    PRIVACY
}

class MainActivity : ComponentActivity() {

    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        // Permissions handled
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Request core dangerous permissions on launch if not granted
        val requiredPerms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requiredPerms.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val ungranted = requiredPerms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (ungranted.isNotEmpty()) {
            requestPermissionsLauncher.launch(ungranted.toTypedArray())
        }

        setContent {
            MaxAssistantTheme {
                MainContent()
            }
        }
    }
}

@Composable
fun MainContent() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val app = context.applicationContext as MaxApplication
    var currentScreen by remember { mutableStateOf(Screen.ASSISTANT) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        app.phoneCommander.navigationEvents.collect { route ->
            when (route) {
                "VISION" -> currentScreen = Screen.VISION
                "ANTI_THEFT" -> currentScreen = Screen.ANTI_THEFT
                "INTRUDER_LOGS" -> currentScreen = Screen.INTRUDER_LOGS
                "WHATSAPP" -> currentScreen = Screen.WHATSAPP
                "SETTINGS" -> currentScreen = Screen.SETTINGS
                "LICENSE" -> currentScreen = Screen.LICENSE
                "PERMISSIONS" -> currentScreen = Screen.PERMISSIONS
                "PRIVACY" -> currentScreen = Screen.PRIVACY
            }
        }
    }

    // Subscreen back navigation handling
    if (currentScreen != Screen.ASSISTANT) {
        BackHandler {
            currentScreen = Screen.ASSISTANT
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavy),
        containerColor = CyberNavy,
        bottomBar = {
            if (currentScreen in listOf(
                    Screen.ASSISTANT,
                    Screen.VISION,
                    Screen.ANTI_THEFT,
                    Screen.WHATSAPP,
                    Screen.SETTINGS
                )
            ) {
                NavigationBar(
                    containerColor = DeepSlate,
                    tonalElevation = 8.dp,
                    modifier = Modifier.testTag("main_navigation_bar")
                ) {
                    NavigationBarItem(
                        selected = currentScreen == Screen.ASSISTANT,
                        onClick = { currentScreen = Screen.ASSISTANT },
                        icon = { Icon(Icons.Default.Mic, contentDescription = "Assistant") },
                        label = { Text("Assistant", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberNavy,
                            selectedTextColor = NeonCyan,
                            indicatorColor = NeonCyan,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_assistant")
                    )

                    NavigationBarItem(
                        selected = currentScreen == Screen.VISION,
                        onClick = { currentScreen = Screen.VISION },
                        icon = { Icon(Icons.Default.CenterFocusStrong, contentDescription = "Vision") },
                        label = { Text("Vision", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberNavy,
                            selectedTextColor = NeonCyan,
                            indicatorColor = NeonCyan,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_vision")
                    )

                    NavigationBarItem(
                        selected = currentScreen == Screen.ANTI_THEFT,
                        onClick = { currentScreen = Screen.ANTI_THEFT },
                        icon = { Icon(Icons.Default.Security, contentDescription = "Anti-Theft") },
                        label = { Text("Security", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberNavy,
                            selectedTextColor = NeonCyan,
                            indicatorColor = NeonCyan,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_antitheft")
                    )

                    NavigationBarItem(
                        selected = currentScreen == Screen.WHATSAPP,
                        onClick = { currentScreen = Screen.WHATSAPP },
                        icon = { Icon(Icons.Default.Chat, contentDescription = "WhatsApp") },
                        label = { Text("WhatsApp", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberNavy,
                            selectedTextColor = NeonCyan,
                            indicatorColor = NeonCyan,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_whatsapp")
                    )

                    NavigationBarItem(
                        selected = currentScreen == Screen.SETTINGS,
                        onClick = { currentScreen = Screen.SETTINGS },
                        icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                        label = { Text("Settings", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberNavy,
                            selectedTextColor = NeonCyan,
                            indicatorColor = NeonCyan,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        ),
                        modifier = Modifier.testTag("nav_settings")
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (currentScreen) {
                Screen.ASSISTANT -> MainAssistantScreen(
                    onNavigateToVision = { currentScreen = Screen.VISION },
                    onNavigateToAntiTheft = { currentScreen = Screen.ANTI_THEFT },
                    onNavigateToWhatsApp = { currentScreen = Screen.WHATSAPP },
                    onNavigateToSettings = { currentScreen = Screen.SETTINGS },
                    onNavigateToLicense = { currentScreen = Screen.LICENSE },
                    onNavigateToPermissions = { currentScreen = Screen.PERMISSIONS }
                )
                Screen.VISION -> VisionScreen()
                Screen.ANTI_THEFT -> AntiTheftScreen(
                    onNavigateToIntruderLogs = { currentScreen = Screen.INTRUDER_LOGS }
                )
                Screen.WHATSAPP -> WhatsAppBotScreen()
                Screen.SETTINGS -> SettingsScreen()
                Screen.INTRUDER_LOGS -> IntruderLogScreen(
                    onNavigateBack = { currentScreen = Screen.ANTI_THEFT }
                )
                Screen.LICENSE -> LicenseScreen(
                    onNavigateBack = { currentScreen = Screen.SETTINGS }
                )
                Screen.PERMISSIONS -> PermissionsScreen(
                    onFinished = { currentScreen = Screen.ASSISTANT }
                )
                Screen.PRIVACY -> PrivacyScreen(
                    onNavigateBack = { currentScreen = Screen.SETTINGS }
                )
            }
        }
    }
}
