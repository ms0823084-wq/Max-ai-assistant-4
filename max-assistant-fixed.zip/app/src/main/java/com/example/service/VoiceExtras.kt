package com.example.service

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import com.example.MaxApplication
import com.example.data.model.PendingAction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Extra voice features inspired by Google Assistant and Voice Access:
 * phone calls by contact name, WhatsApp calls, in-call controls, media keys,
 * quick-settings toggles, time/date/battery, alarms, timers, web search, navigation,
 * and screen control (tap by text, type, edit, swipe, notifications).
 */
class VoiceExtras(
    private val context: Context,
    private val scope: CoroutineScope,
    private val postPending: (PendingAction) -> Unit
) {
    private data class ContactHit(val name: String, val number: String)

    private val app: MaxApplication get() = context.applicationContext as MaxApplication
    private val boss: String get() = app.securityManager.userCallName
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val acc: MaxAccessibilityService? get() = MaxAccessibilityService.instance

    private fun say(text: String) {
        app.ttsManager.speak(text)
    }

    private fun granted(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    private fun startSafely(intent: Intent): Boolean {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    // =========================================================
    // MAIN ENTRY: returns true if the command was handled here
    // =========================================================
    fun handle(l: String): Boolean {
        // ---- Gemini on/off (phone commands keep working either way) ----
        if (l.contains("gemini") && (l.contains(" off") || l.contains("band") || l.contains("disable"))) {
            app.securityManager.isGeminiEnabled = false
            say("Gemini off ho gaya hai.")
            return true
        }
        if (l.contains("gemini") && (l.contains(" on") || l.contains("chalu") || l.contains("enable"))) {
            app.securityManager.isGeminiEnabled = true
            say("Gemini on ho gaya hai.")
            return true
        }

        // ---- Voice unlock ----
        if (l.contains("unlock")) {
            unlockPhone()
            return true
        }

        // ---- In-call controls ----
        val answerWords = listOf("call uthao", "call receive", "phone uthao", "answer call", "call utha", "phone receive", "call accept")
        if (answerWords.any { l.contains(it) }) {
            say(if (answerCall()) "$boss, call utha liya." else "$boss, call nahi utha paya. Accessibility aur phone permission check karein.")
            return true
        }
        val endWords = listOf("call kaato", "call cut", "call band", "end call", "reject call", "call reject",
            "phone kaato", "phone rakh do", "disconnect call", "call disconnect", "call khatam")
        if (endWords.any { l.contains(it) }) {
            say(if (endCall()) "$boss, call kaat diya." else "$boss, call nahi kaat paya.")
            return true
        }
        if (l.contains("speaker on") || l.contains("speaker chalu") || l.contains("speaker karo")) {
            setSpeaker(true)
            say("$boss, speaker on kar diya.")
            return true
        }
        if (l.contains("speaker off") || l.contains("speaker band")) {
            setSpeaker(false)
            say("$boss, speaker band kar diya.")
            return true
        }

        // ---- Calls ----
        val callish = (l.contains("call") || l.contains("dial") ||
                (l.contains("phone") && (l.contains("karo") || l.contains("lagao") || l.contains("laga do")))) &&
                !l.contains("history") && !l.contains("log")
        if (callish && l.contains("whatsapp")) {
            whatsAppCall(l)
            return true
        }
        if (callish) {
            phoneCall(l)
            return true
        }

        // ---- Media keys ----
        if (l.contains("next song") || l.contains("agla gaana") || l.contains("next gaana") || l.contains("gaana badlo")) {
            mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT); say("$boss, agla gaana."); return true
        }
        if (l.contains("previous song") || l.contains("pichhla gaana") || l.contains("previous gaana")) {
            mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS); say("$boss, pichhla gaana."); return true
        }
        if (l.contains("gaana roko") || l.contains("music pause") || l.contains("pause music") || l.contains("song pause") ||
            l.contains("gaana pause") || l.contains("music band") || l.contains("gaana band") || l.contains("music roko")
        ) {
            mediaKey(KeyEvent.KEYCODE_MEDIA_PAUSE); return true
        }
        if (l.contains("music resume") || l.contains("gaana resume") || l.contains("gaana chalu") || l.contains("music chalu") || l.contains("music play")) {
            mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY); return true
        }

        // ---- Time, date, battery ----
        if (l.contains("time kya") || l.contains("kitne baje") || l.contains("what time") || l == "time" || l.contains("samay kya")) {
            say("$boss, abhi ${SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())} baje hain."); return true
        }
        if (l.contains("date kya") || l.contains("aaj ki date") || l.contains("kya tarikh") || l.contains("aaj kya tarikh") || l.contains("today's date")) {
            say("$boss, aaj ${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())} hai."); return true
        }
        if (l.contains("battery kitni") || l.contains("battery level") || l.contains("battery percent") || l.contains("battery kitna")) {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            say("$boss, battery $pct percent hai."); return true
        }

        // ---- Alarm and timer ----
        if (l.contains("alarm") && !l.contains("alarm arm") && !l.contains("arm phone") && (l.contains("lagao") || l.contains("laga do") || l.contains("set")) && l.any { it.isDigit() }) {
            return setAlarm(l)
        }
        if (l.contains("timer") && l.any { it.isDigit() }) {
            return setTimer(l)
        }

        // ---- Web search and navigation ----
        if ((l.startsWith("google") || l.contains("google par")) && l.contains("search") && !l.contains("youtube")) {
            val q = cleanQuery(l, setOf("google", "par", "pe", "search", "karo", "kar", "do", "mein", "me", "ke", "baare", "batao"))
            if (q.isNotBlank()) {
                say("$boss, Google par $q search kar raha hoon.")
                startSafely(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
                return true
            }
        }
        if (l.contains("navigate") || l.contains("rasta") || l.contains("directions") || l.contains("le chalo")) {
            val place = cleanQuery(l, setOf("navigate", "to", "rasta", "batao", "ka", "ko", "ke", "liye", "map", "maps", "par",
                "directions", "chalo", "le", "mujhe", "dikhao", "karo", "me", "mein"))
            if (place.isNotBlank()) {
                say("$boss, $place ka rasta khol raha hoon.")
                val nav = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + URLEncoder.encode(place, "UTF-8")))
                    .setPackage("com.google.android.apps.maps")
                if (!startSafely(nav)) {
                    startSafely(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + URLEncoder.encode(place, "UTF-8"))))
                }
                return true
            }
        }

        // ---- Quick settings toggles ----
        if (quickToggle(l)) return true

        // ---- Voice Access style screen control ----
        return screenControl(l)
    }


    // =========================================================
    // VOICE UNLOCK (PIN only; needs Accessibility service)
    // =========================================================
    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            val wl = pm.newWakeLock(
                android.os.PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                        android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP or
                        android.os.PowerManager.ON_AFTER_RELEASE,
                "max:voice_unlock"
            )
            wl.acquire(8000L)
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun unlockPhone() {
        val sm = app.securityManager
        if (!sm.isVoiceUnlockEnabled || sm.unlockPin.isBlank()) {
            say("$boss, voice unlock band hai. Settings mein on karke PIN set karein.")
            return
        }
        if (sm.isAntiTheftArmed) {
            say("$boss, anti-theft chalu hai, isliye unlock nahi kar sakta.")
            return
        }
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
        if (!km.isKeyguardLocked) {
            say("$boss, phone pehle se unlock hai.")
            return
        }
        val a = acc
        if (a == null) {
            say("$boss, unlock ke liye Accessibility service chalu karein.")
            return
        }
        scope.launch {
            wakeScreen()
            delay(900)
            val dm = context.resources.displayMetrics
            a.swipe(dm.widthPixels * 0.5f, dm.heightPixels * 0.85f, dm.widthPixels * 0.5f, dm.heightPixels * 0.25f, 250)
            delay(1000)
            if (km.isKeyguardLocked) {
                var ok = true
                for (ch in sm.unlockPin) {
                    if (!a.clickExactDigit(ch)) {
                        ok = false
                        break
                    }
                    delay(180)
                }
                if (ok) a.clickKeyguardEnter()
                delay(1200)
            }
            if (!km.isKeyguardLocked) {
                say("$boss, phone unlock ho gaya.")
            } else {
                say("$boss, unlock nahi ho paya. Pattern ya fingerprint lock par ye kaam nahi karta.")
            }
        }
    }

    // =========================================================
    // CALLS
    // =========================================================
    private val callStop = setOf("call", "karo", "kar", "do", "lagao", "laga", "lagana", "ko", "phone", "dial", "par", "pe",
        "mujhe", "ek", "please", "kijiye", "dijiye", "number", "mobile", "wale", "wali", "ka", "ki", "ke", "ne", "aur", "and",
        "then", "karna", "hai", "dena", "de", "whatsapp", "video", "voice")

    private fun spokenNameFrom(l: String): String =
        l.split(Regex("\\s+")).filter { it.isNotBlank() && it !in callStop }.joinToString(" ").trim()

    private fun phoneCall(l: String) {
        val spoken = spokenNameFrom(l)
        if (spoken.isBlank()) {
            say("$boss, kisko call karna hai?")
            return
        }
        val digitCount = spoken.count { it.isDigit() }
        if (digitCount >= 5 && spoken.none { it.isLetter() }) {
            val number = spoken.filter { it.isDigit() || it == '+' }
            postPending(
                PendingAction(
                    actionType = "phone_call",
                    description = "Call $number",
                    spokenPrompt = "$boss, $number par call lagaun?",
                    contactName = number,
                    phoneNumber = number
                )
            )
            return
        }
        scope.launch {
            val hit = resolve(spoken)
            if (hit == null) {
                say(
                    if (!granted(Manifest.permission.READ_CONTACTS)) "$boss, contacts ki permission chahiye. Permissions mein Contacts allow karein."
                    else "$boss, $spoken naam ka contact nahi mila."
                )
            } else {
                postPending(
                    PendingAction(
                        actionType = "phone_call",
                        description = "Call ${hit.name}",
                        spokenPrompt = "$boss, ${hit.name} ko call lagaun?",
                        contactName = hit.name,
                        phoneNumber = hit.number
                    )
                )
            }
        }
    }

    private fun whatsAppCall(l: String) {
        val video = l.contains("video")
        val spoken = spokenNameFrom(l)
        if (spoken.isBlank()) {
            say("$boss, WhatsApp par kisko call karna hai?")
            return
        }
        scope.launch {
            val hit = resolve(spoken)
            if (hit == null) {
                say("$boss, $spoken naam ka contact nahi mila.")
            } else {
                postPending(
                    PendingAction(
                        actionType = "whatsapp_call",
                        description = "WhatsApp ${if (video) "video" else "voice"} call to ${hit.name}",
                        spokenPrompt = "$boss, ${hit.name} ko WhatsApp ${if (video) "video" else "voice"} call lagaun?",
                        recipient = hit.name,
                        messageText = if (video) "video" else "voice",
                        contactName = hit.name
                    )
                )
            }
        }
    }

    /** Called after the user confirms a WhatsApp call. */
    fun startWhatsAppCall(name: String, video: Boolean) {
        val mime = if (video) "vnd.android.cursor.item/vnd.com.whatsapp.video.call"
        else "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        var dataId = -1L
        try {
            context.contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                arrayOf(ContactsContract.Data._ID, ContactsContract.Data.DISPLAY_NAME),
                "${ContactsContract.Data.MIMETYPE}=?",
                arrayOf(mime),
                null
            )?.use { c ->
                while (c.moveToNext()) {
                    val dn = c.getString(1) ?: continue
                    if (dn.equals(name, ignoreCase = true)) {
                        dataId = c.getLong(0)
                        break
                    }
                }
            }
        } catch (e: Exception) {
            dataId = -1L
        }
        if (dataId >= 0) {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.parse("content://com.android.contacts/data/$dataId"), mime)
                setPackage("com.whatsapp")
            }
            if (startSafely(intent)) {
                say("$boss, $name ko WhatsApp call lagaya ja raha hai.")
                return
            }
        }
        say("$boss, WhatsApp par $name ka call shuru nahi ho paya. WhatsApp khol raha hoon.")
        startSafely(Intent(Intent.ACTION_VIEW, Uri.parse("whatsapp://send")).setPackage("com.whatsapp"))
    }

    private fun loadContacts(): List<ContactHit> {
        if (!granted(Manifest.permission.READ_CONTACTS)) return emptyList()
        val out = mutableListOf<ContactHit>()
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val p = c.getString(1) ?: continue
                    out.add(ContactHit(n, p))
                }
            }
        } catch (e: Exception) {
            // ignore
        }
        return out
    }

    private val aliasGroups = listOf(
        listOf("mummy", "mom", "maa", "mother", "mama", "mumma", "मम्मी", "माँ", "मां"),
        listOf("papa", "dad", "father", "pappa", "पापा", "पिताजी"),
        listOf("bhai", "bhaiya", "brother", "भाई", "भैया"),
        listOf("didi", "behen", "sister", "दीदी", "बहन"),
        listOf("wife", "biwi", "बीवी", "पत्नी"),
        listOf("husband", "पति")
    )

    private fun score(contact: String, spoken: String): Int {
        val c = contact.lowercase(Locale.ROOT).trim()
        val s = spoken.lowercase(Locale.ROOT).trim()
        val variants = aliasGroups.firstOrNull { g -> g.any { it == s } } ?: listOf(s)
        if (c == s) return 100
        if (variants.any { c == it }) return 95
        if (c.startsWith(s)) return 80
        if (c.split(" ").any { it == s }) return 70
        if (variants.any { c.contains(it) }) return 60
        if (c.contains(s)) return 50
        return 0
    }

    private suspend fun resolve(spoken: String): ContactHit? {
        val contacts = withContext(Dispatchers.IO) { loadContacts() }
        if (contacts.isEmpty()) return null
        var best: ContactHit? = null
        var bestScore = 0
        for (c in contacts) {
            val sc = score(c.name, spoken)
            if (sc > bestScore) {
                bestScore = sc
                best = c
            }
        }
        if (best != null && bestScore >= 50) return best

        // Hindi-script or unusual spelling: ask Gemini to match against the contact list.
        val apiKey = app.securityManager.activeGeminiKey
        if (apiKey.isBlank()) return null
        val names = contacts.map { it.name }.distinct().take(300)
        val prompt = "Spoken name: \"$spoken\" (may be in Hindi script or Hinglish). " +
                "Contact names: ${names.joinToString(" | ")}. " +
                "Reply with ONLY the single best matching contact name exactly as written in the list, or NONE if there is no reasonable match."
        val res = app.geminiService.generateReply(
            prompt, emptyList(),
            "You are a precise contact-name matcher. Output only the contact name or NONE.", apiKey
        )
        val answer = res.getOrNull()?.trim()?.trim('"') ?: return null
        return contacts.firstOrNull { it.name.equals(answer, ignoreCase = true) }
    }

    @Suppress("DEPRECATION")
    private fun answerCall(): Boolean {
        if (granted(Manifest.permission.ANSWER_PHONE_CALLS)) {
            try {
                val tm = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                tm.acceptRingingCall()
                return true
            } catch (e: Exception) {
                // fall through to accessibility
            }
        }
        val a = acc ?: return false
        return a.clickNodeWithText("Answer") || a.clickNodeWithText("Accept") || a.clickNodeWithText("उत्तर")
    }

    @Suppress("DEPRECATION")
    private fun endCall(): Boolean {
        if (granted(Manifest.permission.ANSWER_PHONE_CALLS)) {
            try {
                val tm = context.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
                if (tm.endCall()) return true
            } catch (e: Exception) {
                // fall through to accessibility
            }
        }
        val a = acc ?: return false
        return a.clickNodeWithText("End call") || a.clickNodeWithText("Decline") || a.clickNodeWithText("Reject") || a.clickNodeWithText("कॉल समाप्त")
    }

    @Suppress("DEPRECATION")
    private fun setSpeaker(on: Boolean) {
        val a = acc
        if (on && a != null && a.clickNodeWithText("Speaker")) return
        try {
            audio.isSpeakerphoneOn = on
        } catch (e: Exception) {
            // ignore
        }
    }

    // =========================================================
    // MEDIA, ALARM, TIMER
    // =========================================================
    private fun mediaKey(code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun setAlarm(l: String): Boolean {
        val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?").find(l) ?: return false
        var hour = m.groupValues[1].toInt()
        val minute = m.groupValues[2].toIntOrNull() ?: 0
        val pm = l.contains("shaam") || l.contains("raat") || l.contains("dopahar") || l.contains(" pm")
        if (pm && hour < 12) hour += 12
        if (hour > 23 || minute > 59) return false
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        say(if (startSafely(intent)) "$boss, alarm ${"%02d:%02d".format(hour, minute)} ke liye laga diya." else "$boss, alarm nahi laga paya.")
        return true
    }

    private fun setTimer(l: String): Boolean {
        val m = Regex("(\\d+)\\s*(minute|min|second|sec|ghanta|hour)").find(l) ?: return false
        val n = m.groupValues[1].toInt()
        val seconds = when (m.groupValues[2]) {
            "second", "sec" -> n
            "ghanta", "hour" -> n * 3600
            else -> n * 60
        }
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        say(if (startSafely(intent)) "$boss, ${m.groupValues[1]} ${m.groupValues[2]} ka timer laga diya." else "$boss, timer nahi laga paya.")
        return true
    }

    private fun cleanQuery(l: String, stop: Set<String>): String =
        l.split(Regex("\\s+")).filter { it.isNotBlank() && it !in stop }.joinToString(" ").trim()

    // =========================================================
    // QUICK SETTINGS TOGGLES (Bluetooth, Wi-Fi, etc.)
    // =========================================================
    private fun quickToggle(l: String): Boolean {
        val wantsOn = l.contains(" on") || l.contains("chalu") || l.contains("enable") || l.contains("start")
        val wantsOff = l.contains(" off") || l.contains("band") || l.contains("disable") || l.contains("stop")
        val toggleWord = wantsOn || wantsOff || l.contains("toggle")
        if (!toggleWord) return false

        val tiles: List<Pair<List<String>, List<String>>> = listOf(
            listOf("bluetooth") to listOf("Bluetooth"),
            listOf("wifi", "wi-fi") to listOf("Wi-Fi", "WLAN", "Wi‑Fi"),
            listOf("airplane", "flight mode") to listOf("Airplane mode", "Flight mode"),
            listOf("hotspot") to listOf("Hotspot"),
            listOf("do not disturb", "dnd") to listOf("Do not disturb", "DND"),
            listOf("rotation", "auto rotate", "auto-rotate") to listOf("Auto-rotate", "Auto rotate", "Rotation"),
            listOf("battery saver", "power saving") to listOf("Battery saver", "Power saving")
        )
        val tile = tiles.firstOrNull { (keys, _) -> keys.any { l.contains(it) } } ?: return false
        val keyName = tile.first.first()
        val a = acc
        if (a == null) {
            say("$boss, $keyName badalne ke liye Accessibility service chalu karein.")
            return true
        }
        scope.launch {
            a.triggerQuickSettings()
            delay(1400)
            var desc: String? = null
            var label: String? = null
            for (lab in tile.second) {
                val d = a.describeNode(lab)
                if (d != null) {
                    desc = d
                    label = lab
                    break
                }
            }
            if (label == null) {
                a.triggerBack()
                say("$boss, quick settings mein $keyName ka button nahi mila.")
                return@launch
            }
            val isOff = Regex("\\boff\\b", RegexOption.IGNORE_CASE).containsMatchIn(desc.orEmpty())
            val isOn = !isOff && Regex("\\bon\\b", RegexOption.IGNORE_CASE).containsMatchIn(desc.orEmpty())
            if (wantsOn && isOn) {
                a.triggerBack()
                say("$boss, $keyName pehle se on hai.")
                return@launch
            }
            if (wantsOff && isOff) {
                a.triggerBack()
                say("$boss, $keyName pehle se off hai.")
                return@launch
            }
            a.clickNodeWithText(label)
            delay(600)
            a.triggerBack()
            say(if (wantsOn) "$boss, $keyName on kar diya." else if (wantsOff) "$boss, $keyName off kar diya." else "$boss, $keyName badal diya.")
        }
        return true
    }

    // =========================================================
    // VOICE ACCESS STYLE SCREEN CONTROL
    // =========================================================
    private fun screenControl(l: String): Boolean {
        val a = acc

        if (l.contains("notification kholo") || l.contains("notifications kholo") || l.contains("notification dikhao") || l.contains("open notifications")) {
            a?.triggerNotifications(); return true
        }
        if (l.contains("quick settings")) {
            a?.triggerQuickSettings(); return true
        }

        // Swipe gestures
        val dm = context.resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        if (l.contains("swipe left") || l.contains("left swipe") || l.contains("agla page") || l.contains("next page")) {
            a?.swipe(w * 0.8f, h * 0.5f, w * 0.2f, h * 0.5f, 300); return true
        }
        if (l.contains("swipe right") || l.contains("right swipe") || l.contains("pichhla page") || l.contains("previous page")) {
            a?.swipe(w * 0.2f, h * 0.5f, w * 0.8f, h * 0.5f, 300); return true
        }

        // Enter / search key
        if (l == "enter" || l == "enter dabao" || l == "press enter" || l == "search dabao") {
            a?.pressEnter(); return true
        }

        // Text editing
        if (l == "select all" || l == "sab select karo") { a?.editAction("selectall"); return true }
        if (l == "copy" || l == "copy karo") { a?.editAction("copy"); return true }
        if (l == "paste" || l == "paste karo") { a?.editAction("paste"); return true }
        if (l == "cut" || l == "cut karo") { a?.editAction("cut"); return true }
        if (l == "delete text" || l == "text delete karo" || l == "mita do" || l == "clear text") { a?.editAction("clear"); return true }

        // Typing: "type hello", "likho hello"
        val typeMatch = Regex("^(?:type|likho|likh do|write)\\s+(.+)$").find(l)
        if (typeMatch != null) {
            val text = typeMatch.groupValues[1].trim()
            if (a == null) {
                say("$boss, likhne ke liye Accessibility service chalu karein.")
            } else if (!a.typeTextIntoFocused(text)) {
                say("$boss, koi text box select nahi hai.")
            }
            return true
        }

        // Tap by label: "tap play", "click subscribe", "subscribe dabao"
        if (l.contains("likha hai") || l.contains("like karo") || l.contains("reel")) return false
        val tapA = Regex("^(?:tap|click|press|select|dabao|chuno)\\s+(?:on\\s+)?(.+)$").find(l)
        val tapB = Regex("^(.+?)\\s+(?:ko\\s+)?(?:par\\s+)?(?:tap|click|dabao|dabana|press)(?:\\s+karo)?$").find(l)
        val target = (tapA?.groupValues?.get(1) ?: tapB?.groupValues?.get(1))?.trim()
        if (!target.isNullOrBlank() && target != "enter" && target.length <= 40) {
            if (a == null) {
                say("$boss, tap karne ke liye Accessibility service chalu karein.")
                return true
            }
            if (!a.clickNodeWithText(target)) {
                a.clickTextViaOcr(target) { _, msg -> say(msg) }
            }
            return true
        }
        return false
    }
}
